
function Greetings () {

    return (

        <h2>Hello React!</h2>

    )


}

export default Greetings;