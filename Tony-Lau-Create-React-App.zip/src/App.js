import logo from './logo.svg';
import './App.css';
import React from 'react';
import Greetings from './components/Greetings';

function App() {
  return (
    <div className="App">
      
      <div> 
        <h1>Hello World</h1>
        <Greetings />

      </div>


    </div>
  );
}

export default App;
